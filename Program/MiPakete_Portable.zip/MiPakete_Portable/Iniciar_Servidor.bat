@echo off
title Mi Pakete - Servidor Multimedia
cd /d "%~dp0"
start "" "MiPakete.exe"
