@echo off
cd /d "%~dp0"
start /min "" "MiPakete.exe" --silent
