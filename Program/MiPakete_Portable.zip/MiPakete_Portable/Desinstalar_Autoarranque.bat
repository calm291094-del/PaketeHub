@echo off
title Mi Pakete - Desinstalar Autoarranque
cd /d "%~dp0"
"MiPakete.exe" --remove
