@echo off
title Mi Pakete - Instalar Autoarranque
cd /d "%~dp0"
"MiPakete.exe" --install
